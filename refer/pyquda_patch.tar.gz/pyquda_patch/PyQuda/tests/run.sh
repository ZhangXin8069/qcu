echo "mpiexec -np 1 python test.dslash.mpi.py"
mpiexec -n 1 python test.dslash.mpi.py

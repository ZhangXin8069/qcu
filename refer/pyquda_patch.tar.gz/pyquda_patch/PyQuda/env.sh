export LD_LIBRARY_PATH=$(pwd)/lib/:$LD_LIBRARY_PATH
#export PYTHONPATH=/home/aistudio/external-libraries/:$PYTHONPATH

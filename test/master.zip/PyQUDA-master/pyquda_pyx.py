import os
import sys
from typing import Dict, List, NamedTuple, Union


class QudaEnumMeta(NamedTuple):
    name: str
    value: Union[int, str]

    def __repr__(self) -> str:
        return f"{self.name} = {self.value}"


class QudaParamsMeta(NamedTuple):
    name: str
    type: str
    ptr: str
    array: List[int]

    def __repr__(self) -> str:
        self_array = "" if len(self.array) == 0 else f"[{']['.join(self.array)}]"
        return f"{self.type} {self.ptr}{self.name}{self_array}"


normal = """
    @property
    def %name%(self):
        return self.param.%name%

    @%name%.setter
    def %name%(self, value):
        self.param.%name% = value
"""

cstring = """
    @property
    def %name%(self):
        return self.param.%name%

    @%name%.setter
    def %name%(self, const char value[]):
        self.param.%name% = value
"""

param = """
    @property
    def %name%(self):
        param = %type%()
        param.from_ptr(self.param.%name%)
        return param

    @%name%.setter
    def %name%(self, value):
        self.set_%name%(value)

    cdef set_%name%(self, QudaInvertParam value):
        self.param.%name% = &value.param
"""

multigrid = """
    @property
    def %name%(self):
        value = []
        for i in range(self.n_level):
            value.append(self.param.%name%[i])
        return value

    @%name%.setter
    def %name%(self, value):
        for i in range(self.n_level):
            self.param.%name%[i] = value[i]
"""

multigrid_param = """
    @property
    def %name%(self):
        params = []
        for i in range(self.param.n_level):
            param = %type%()
            param.from_ptr(self.param.%name%[i])
            params.append(param)
        return params

    @%name%.setter
    def %name%(self, value):
        for i in range(self.param.n_level):
            self.set_%name%(value[i], i)

    cdef set_%name%(self, %type% value, int i):
        self.param.%name%[i] = &value.param
"""

void_ptr = """
    @property
    def %name%(self):
        ptr = Pointer("void")
        ptr.set_ptr(self.param.%name%)
        return ptr

    @%name%.setter
    def %name%(self, value):
        self.set_%name%(value)

    cdef set_%name%(self, Pointer value):
        assert value.dtype == "void"
        self.param.%name% = value.ptr
"""

ptr = """
    @property
    def %name%(self):
        ptr = Pointer("%type%")
        ptr.set_ptr(self.param.%name%)
        return ptr

    @%name%.setter
    def %name%(self, value):
        self.set_%name%(value)

    cdef set_%name%(self, Pointer value):
        assert value.dtype == "%type%"
        self.param.%name% = <%type% *>value.ptr
"""

ptrptr = """
    @property
    def %name%(self):
        ptr = Pointers("%type%", self.param.num_paths)
        ptr.set_ptrs(<void **>self.param.%name%)
        return ptr

    @%name%.setter
    def %name%(self, value):
        self.set_%name%(value)

    cdef set_%name%(self, Pointers value):
        assert value.dtype == "%type%"
        self.param.%name% = <%type% **>value.ptrs
"""


def build_pyquda_pyx(pyquda_root, quda_path):
    fake_libc_include = os.path.join(pyquda_root, "pycparser", "utils", "fake_libc_include")
    quda_include = os.path.join(quda_path, "include")
    assert os.path.exists(fake_libc_include), f"{fake_libc_include} not found"
    print(f"Building pyquda wrapper from {os.path.join(quda_include, 'quda.h')}")
    sys.path.insert(1, os.path.join(pyquda_root, "pycparser"))
    try:
        from pycparser import parse_file, c_ast
    except ImportError or ModuleNotFoundError:
        from pycparser.pycparser import parse_file, c_ast  # This is for the language server
    sys.path.remove(os.path.join(pyquda_root, "pycparser"))

    def evaluate(node):
        if node is None:
            return
        elif type(node) is c_ast.UnaryOp:
            if node.op == "+":
                return evaluate(node.expr)
            elif node.op == "-":
                return -evaluate(node.expr)
        elif type(node) is c_ast.BinaryOp:
            if node.op == "+":
                return evaluate(node.left) + evaluate(node.right)
            elif node.op == "-":
                return evaluate(node.left) - evaluate(node.right)
        elif type(node) is c_ast.Constant:
            return int(node.value, 0)
        elif type(node) is c_ast.ID:
            return node.name
        else:
            raise ValueError(f"Unknown node {node}")

    quda_enum_meta: Dict[str, List[QudaParamsMeta]] = {}
    quda_params_meta: Dict[str, List[QudaParamsMeta]] = {}
    ast = parse_file(
        os.path.join(quda_include, "quda.h"),
        use_cpp=True,
        cpp_path="cc",
        cpp_args=[
            "-E",
            Rf"-I{fake_libc_include}",
            Rf"-I{quda_include}",
        ],
    )
    for node in ast:
        if node.name.startswith("Quda") and type(node.type.type) is c_ast.Enum:
            quda_enum_meta[node.name] = []
            current_value = -1
            for item in node.type.type.values:
                item_value = evaluate(item.value)
                if item_value is not None:
                    current_value = item_value
                else:
                    current_value += 1
                if "INVALID" in item.name:
                    quda_enum_meta[node.name].append(QudaEnumMeta(item.name, "QUDA_INVALID_ENUM"))
                else:
                    quda_enum_meta[node.name].append(QudaEnumMeta(item.name, current_value))
        if node.name.startswith("Quda") and node.name.endswith("Param"):
            quda_params_meta[node.name] = []
            # print(node.name)
            for decl in node.type.type.decls:
                n, t = decl.name, decl.type
                tt = t.type
                if type(t) is c_ast.TypeDecl:
                    quda_params_meta[node.name].append(QudaParamsMeta(n, " ".join(tt.names), "", []))
                    # print(" ".join(t.type.names), n)
                elif type(t) is c_ast.ArrayDecl:
                    ttt = tt.type
                    if type(tt) is c_ast.TypeDecl:
                        quda_params_meta[node.name].append(QudaParamsMeta(n, " ".join(ttt.names), "", [t.dim.value]))
                        # print(" ".join(t.type.type.names), n, f"[{t.dim.value}]")
                    elif type(tt) is c_ast.PtrDecl:
                        quda_params_meta[node.name].append(
                            QudaParamsMeta(n, " ".join(ttt.type.names), "*", [t.dim.value])
                        )
                        # print(" ".join(t.type.type.type.names), "*", n, f"[{t.dim.value}]")
                    elif type(tt) is c_ast.ArrayDecl:
                        quda_params_meta[node.name].append(
                            QudaParamsMeta(n, " ".join(ttt.type.names), "", [t.dim.value, tt.dim.value])
                        )
                        # print(" ".join(t.type.type.type.names), n, f"[{t.dim.value}][{t.type.dim.value}]")
                    else:
                        raise ValueError(f"Unexpected node {node}")
                elif type(t) is c_ast.PtrDecl:
                    ttt = tt.type
                    if type(tt) is c_ast.TypeDecl:
                        quda_params_meta[node.name].append(QudaParamsMeta(n, " ".join(ttt.names), "*", ""))
                        # print(" ".join(t.type.type.names), "*", n)
                    elif type(tt) is c_ast.PtrDecl:
                        quda_params_meta[node.name].append(QudaParamsMeta(n, " ".join(ttt.type.names), "**", ""))
                        # print(" ".join(t.type.type.type.names), "**", n)
                    else:
                        raise ValueError(f"Unexpected node {node}")
                else:
                    raise ValueError(f"Unexpected node {node}")

    with open(os.path.join(quda_include, "enum_quda.h"), "r") as f:
        enum_quda_h = f.read()
    with open(os.path.join(pyquda_root, "pyquda", "enum_quda.in.py"), "r") as f:
        enum_quda_py = f.read()
    with open(os.path.join(pyquda_root, "pyquda", "src", "quda.in.pxd"), "r") as f:
        quda_pxd = f.read()
    with open(os.path.join(pyquda_root, "pyquda", "src", "pyquda.in.pyx"), "r") as f:
        pyquda_pyx = f.read()
    # with open(os.path.join(pyquda_root, "pyquda", "pyquda.in.pyi"), "r") as f:
    #     pyquda_pyi = f.read()

    enum_quda_start = enum_quda_py.find("\nQUDA_INVALID_ENUM = -0x7FFFFFFF - 1")
    quda_constants_pxd = 'cdef extern from "quda_constants.h":\n    cdef enum:'
    start = enum_quda_py.find("\nQUDA", 0)
    while enum_quda_start > start >= 0:
        stop = enum_quda_py.find(" =", start)
        quda_constants_pxd += f"\n        {enum_quda_py[start + 1 : stop]}\n"
        start = enum_quda_py.find("\nQUDA", stop)

    enum_quda_pxd = 'cdef extern from "enum_quda.h":'
    start = enum_quda_py.find("\nclass ", enum_quda_start)
    while start >= 0:
        stop = enum_quda_py.find("(IntEnum):", start)
        enum_quda_pxd += f"\n    ctypedef enum {enum_quda_py[start + 7 : stop]}:\n        pass\n"
        start = enum_quda_py.find("\nclass ", stop)

    for key, val in quda_enum_meta.items():
        enum_quda_py_block = ""
        for item in val:
            comment = ""
            idx = enum_quda_h.find(item.name)
            idx_comment = enum_quda_h.find("//", idx)
            idx_endline = enum_quda_h.find("\n", idx)
            if idx_comment != -1 and idx_comment < idx_endline:
                comment = f'\n    """{enum_quda_h[idx_comment + 2 : idx_endline].strip()}"""'
            enum_quda_py_block += f"    {item}{comment}\n"
        idx = enum_quda_py.find(key)
        enum_quda_py = enum_quda_py[:idx] + enum_quda_py[idx:].replace("    pass\n", enum_quda_py_block, 1)

    for key, val in quda_params_meta.items():
        quda_pxd_block = ""
        pyquda_pyx_block = ""
        pyquda_pyi_block = ""
        for item in val:
            quda_pxd_block += f"        {item}\n"
            if len(item.array) > 0 and item.type.startswith("Quda") and item.type.endswith("Param"):
                pyquda_pyx_block += multigrid_param.replace("%name%", item.name).replace("%type%", item.type)
                pyquda_pyi_block += f"    {item.name}: List[{item.type}, {item.array[0]}]\n"
            elif item.type.startswith("Quda") and item.type.endswith("Param"):
                pyquda_pyx_block += param.replace("%name%", item.name).replace("%type%", item.type)
                pyquda_pyi_block += f"    {item.name}: {item.type}\n"
            elif len(item.array) == 1:
                if item.type == "char":
                    pyquda_pyx_block += cstring.replace("%name%", item.name)
                    pyquda_pyi_block += f"    {item.name}: bytes[{item.array[0]}]\n"
                else:
                    pyquda_pyx_block += normal.replace("%name%", item.name)
                    pyquda_pyi_block += f"    {item.name}: List[{item.type}, {item.array[0]}]\n"
            elif len(item.array) == 2:
                pyquda_pyx_block += multigrid.replace("%name%", item.name)
                if item.type == "char":
                    pyquda_pyi_block += f"    {item.name}: List[bytes[{item.array[1]}], {item.array[0]}]\n"
                else:
                    pyquda_pyi_block += f"    {item.name}: List[List[{item.type}, {item.array[1]}], {item.array[0]}]\n"
            elif item.ptr == "*" and item.type == "void":
                pyquda_pyx_block += void_ptr.replace("%name%", item.name)
                pyquda_pyi_block += f"    {item.name}: Pointer\n"
            elif item.ptr == "*":
                pyquda_pyx_block += ptr.replace("%name%", item.name).replace("%type%", item.type)
                pyquda_pyi_block += f"    {item.name}: Pointer\n"
            elif item.ptr == "**":
                pyquda_pyx_block += ptrptr.replace("%name%", item.name).replace("%type%", item.type)
                pyquda_pyi_block += f"    {item.name}: Pointers\n"
            else:
                pyquda_pyx_block += normal.replace("%name%", item.name)
                pyquda_pyi_block += f"    {item.name}: {item.type}\n"
        idx = quda_pxd.find(key)
        quda_pxd = quda_pxd[:idx] + quda_pxd[idx:].replace(
            "        pass\n", quda_pxd_block.replace("double _Complex", "double_complex"), 1
        )
        pyquda_pyx = pyquda_pyx.replace(
            f"\n##%%!! {key}\n",
            pyquda_pyx_block.replace("double _Complex", "double_complex"),
        )
        # pyquda_pyi = pyquda_pyi.replace(
        #     f"##%%!! {key}\n",
        #     pyi.replace("double _Complex", "double_complex").replace("unsigned int", "int"),
        # )

    with open(os.path.join(pyquda_root, "pyquda", "src", "quda_constants.pxd"), "w") as f:
        f.write(quda_constants_pxd)
    with open(os.path.join(pyquda_root, "pyquda", "src", "enum_quda.pxd"), "w") as f:
        f.write(enum_quda_pxd)
    with open(os.path.join(pyquda_root, "pyquda", "src", "quda.pxd"), "w") as f:
        f.write(quda_pxd)
    with open(os.path.join(pyquda_root, "pyquda", "src", "pyquda.pyx"), "w") as f:
        f.write(pyquda_pyx)
    with open(os.path.join(pyquda_root, "pyquda", "enum_quda.py"), "w") as f:
        f.write(enum_quda_py)

    # with open(os.path.join(pyquda_root, "pyquda", "pyquda.pyi"), "w") as f:
    #     f.write(pyquda_pyi)

    if os.path.exists(os.path.join(pyquda_root, "yacctab.py")):
        os.remove(os.path.join(pyquda_root, "yacctab.py"))
    if os.path.exists(os.path.join(pyquda_root, "lextab.py")):
        os.remove(os.path.join(pyquda_root, "lextab.py"))
